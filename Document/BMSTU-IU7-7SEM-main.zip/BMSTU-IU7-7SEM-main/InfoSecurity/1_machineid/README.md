Only modified files of the Computer Graphics course project
