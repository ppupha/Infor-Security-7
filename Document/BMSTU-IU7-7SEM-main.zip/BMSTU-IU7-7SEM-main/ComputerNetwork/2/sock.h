#ifndef SOCK_H
#define SOCK_H

#include <stdlib.h>
#include <unistd.h>

// #define SOCK_ADDR "localhost"
#define SOCK_ADDR "127.0.0.1"
#define SOCK_PORT 8888
#define BUF_SIZE 32

#endif