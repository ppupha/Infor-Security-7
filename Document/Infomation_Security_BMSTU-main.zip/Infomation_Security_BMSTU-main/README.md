# Infomation_Security_BMSTU
**Преподаватель:** Григорьев Александр Сергеевич
